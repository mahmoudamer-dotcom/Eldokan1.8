<?php
/**
 * Plugin Name: ElDokan Checkout Setup
 * Description: Admin settings for the existing ElDokan Customer API 0.8.0 checkout adapter.
 * Version: 0.1.0
 * Requires PHP: 8.0
 */
if (!defined('ABSPATH')) { exit; }

final class ElDokan_Checkout_Setup {
    private const MAP = 'eldokan_checkout_setup_shipping_types';
    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_post_eldokan_checkout_setup_save', [__CLASS__, 'save']);
        add_filter('eldokan_customer_api_checkout_shipping_type', [__CLASS__, 'shipping_type'], 20, 2);
    }
    private static function methods() {
        if (!function_exists('WC') || !WC()->shipping()) { return []; }
        WC()->shipping()->load_shipping_methods();
        return WC()->shipping()->get_shipping_methods();
    }
    private static function gateways() {
        return function_exists('WC') ? WC()->payment_gateways()->payment_gateways() : [];
    }
    public static function shipping_type($default, $method) {
        $map = get_option(self::MAP, []);
        $type = is_array($map) ? ($map[$method] ?? '') : '';
        return in_array($type, ['door_delivery', 'pickup'], true) ? $type : $default;
    }
    public static function menu() {
        add_submenu_page('woocommerce', 'ElDokan Checkout', 'ElDokan Checkout', 'manage_woocommerce', 'eldokan-checkout-setup', [__CLASS__, 'page']);
    }
    public static function save() {
        if (!current_user_can('manage_woocommerce')) { wp_die('Not allowed.', '', ['response' => 403]); }
        check_admin_referer('eldokan_checkout_setup_save');
        $origin = isset($_POST['frontend_origin']) && is_string($_POST['frontend_origin']) ? trim(wp_unslash($_POST['frontend_origin'])) : '';
        $parts = wp_parse_url($origin);
        if ($origin !== '' && (!filter_var($origin, FILTER_VALIDATE_URL) || !$parts || ($parts['scheme'] ?? '') !== 'https' || empty($parts['host']) || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment']) || !in_array($parts['path'] ?? '', ['', '/'], true))) {
            wp_die('Enter the HTTPS storefront origin only, for example https://shop.example.com (without a page path).');
        }
        $id = isset($_POST['gateway_id']) && is_string($_POST['gateway_id']) ? sanitize_text_field(wp_unslash($_POST['gateway_id'])) : '';
        $gateways = self::gateways();
        if ($id !== '' && (!isset($gateways[$id]) || !is_a($gateways[$id], 'Paymob_Payment') || is_a($gateways[$id], 'Paymob_Main_Gateway') || is_a($gateways[$id], 'Paymob_Subscription_Gateway') || $id === 'paymob-pixel')) {
            wp_die('Select an installed native hosted Paymob gateway.');
        }
        $submitted = isset($_POST['shipping_types']) && is_array($_POST['shipping_types']) ? wp_unslash($_POST['shipping_types']) : [];
        $map = [];
        foreach (self::methods() as $method) {
            $method_id = $method->id;
            $type = $submitted[$method_id] ?? '';
            if (is_string($type) && in_array($type, ['door_delivery', 'pickup'], true)) { $map[$method_id] = $type; }
        }
        update_option('eldokan_customer_api_frontend_origin', rtrim($origin, '/'), false);
        if ($id !== '') { update_option('eldokan_customer_api_paymob_gateway', $id, false); }
        update_option('eldokan_customer_api_paymob_callback_profile', isset($_POST['accept_transaction']) && $_POST['accept_transaction'] === '1' ? 'accept_transaction' : '', false);
        update_option(self::MAP, $map, false);
        wp_safe_redirect(admin_url('admin.php?page=eldokan-checkout-setup&saved=1'));
        exit;
    }
    public static function page() {
        if (!current_user_can('manage_woocommerce')) { return; }
        $origin = get_option('eldokan_customer_api_frontend_origin', '');
        $gateway_id = get_option('eldokan_customer_api_paymob_gateway', 'paymob');
        $profile = get_option('eldokan_customer_api_paymob_callback_profile', '');
        $map = get_option(self::MAP, []);
        $map = is_array($map) ? $map : [];
        echo '<div class="wrap"><h1>ElDokan Checkout — إعداد إتمام الشراء</h1>';
        if (isset($_GET['saved'])) { echo '<div class="notice notice-success"><p>تم حفظ إعدادات الربط.</p></div>'; }
        echo '<p>هذه الشاشة تضبط محول Customer API الحالي. تكلفة الشحن تأتي من مناطق الشحن في WooCommerce، والدفع من بوابة Paymob المثبتة.</p>';
        echo '<h2>حالة المتطلبات</h2><ul>';
        echo '<li>Customer API: <strong>' . esc_html(defined('ELDOKAN_CUSTOMER_API_VERSION') ? ELDOKAN_CUSTOMER_API_VERSION : 'غير مفعّل') . '</strong></li>';
        echo '<li>Paymob: <strong>' . esc_html(defined('PAYMOB_VERSION') ? PAYMOB_VERSION : 'غير مفعّل') . '</strong> — محول Customer API 0.8.0 يشترط 4.1.15 تحديدًا.</li>';
        echo '<li>WooCommerce: <strong>' . esc_html(defined('WC_VERSION') ? WC_VERSION : 'غير مفعّل') . '</strong></li></ul>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="eldokan_checkout_setup_save">';
        wp_nonce_field('eldokan_checkout_setup_save');
        echo '<h2>ربط Paymob</h2><p><label>عنوان واجهة المتجر HTTPS<br><input type="url" name="frontend_origin" class="regular-text" dir="ltr" placeholder="https://shop.example.com" value="' . esc_attr($origin) . '"></label></p>';
        echo '<p>اكتب الدومين فقط. الرجوع بعد الدفع سيكون إلى /orders/…؛ localhost غير مدعوم في محول الإضافة، استخدم رابط HTTPS للتطوير.</p>';
        echo '<p><label>بوابة Paymob hosted <select name="gateway_id"><option value="">اختر البوابة</option>';
        foreach (self::gateways() as $id => $gateway) {
            if (!is_a($gateway, 'Paymob_Payment') || is_a($gateway, 'Paymob_Main_Gateway') || is_a($gateway, 'Paymob_Subscription_Gateway') || $id === 'paymob-pixel') { continue; }
            echo '<option value="' . esc_attr($id) . '" ' . selected($gateway_id, $id, false) . '>' . esc_html($gateway->get_method_title() . ' [' . $id . ']') . '</option>';
        }
        echo '</select></label></p>';
        echo '<p><label><input type="checkbox" name="accept_transaction" value="1" ' . checked($profile, 'accept_transaction', false) . '> تم التحقق أن Paymob يرسل Callback من نوع Accept TRANSACTION إلى إضافة WooCommerce الأصلية.</label></p>';
        echo '<p>تحديد هذا المربع يعلن توافق إعداد الـCallback؛ لا يغيّر إعدادات حساب Paymob. تفعيل البوابة ومفاتيحها يتم من إعدادات Paymob الأصلية.</p>';
        echo '<h2>تصنيف طرق الشحن</h2><p>اترك الطرق القياسية على تلقائي. اختر توصيل للمنزل فقط لطريقة توصيل مثبتة فعلًا، أو استلام لطريقة استلام. التصنيف لا ينشئ سعرًا ولا يضيف منطقة شحن.</p><table class="widefat striped"><thead><tr><th>الطريقة</th><th>معرف WooCommerce</th><th>التصنيف</th></tr></thead><tbody>';
        foreach (self::methods() as $method) {
            $id = $method->id;
            echo '<tr><td>' . esc_html($method->get_method_title()) . '</td><td><code>' . esc_html($id) . '</code></td><td><select name="shipping_types[' . esc_attr($id) . ']">';
            foreach (['' => 'تلقائي / بدون تخصيص', 'door_delivery' => 'توصيل للمنزل', 'pickup' => 'استلام من المتجر'] as $value => $label) {
                echo '<option value="' . esc_attr($value) . '" ' . selected($map[$id] ?? '', $value, false) . '>' . esc_html($label) . '</option>';
            }
            echo '</select></td></tr>';
        }
        echo '</tbody></table>';
        submit_button('حفظ إعدادات الربط');
        echo '</form><p><a href="' . esc_url(admin_url('admin.php?page=wc-settings&tab=shipping')) . '">مناطق وتكلفة الشحن</a> · <a href="' . esc_url(admin_url('admin.php?page=wc-settings&tab=checkout')) . '">تفعيل وسائل الدفع</a></p></div>';
    }
}
ElDokan_Checkout_Setup::init();